document.getElementById('year').textContent = new Date().getFullYear();

const toggle = document.getElementById('chat-toggle');
const bot = document.getElementById('chatbot');
const input = document.getElementById('chatInput');
const body = document.getElementById('chatBody');

toggle.onclick = () => { bot.style.display = bot.style.display === 'none' ? 'block' : 'none'; };

input.addEventListener('keydown', e => {
  if (e.key === 'Enter' && input.value.trim()) {
    const userMsg = document.createElement('div');
    userMsg.className = 'msg user';
    userMsg.textContent = input.value;
    body.appendChild(userMsg);

    const botMsg = document.createElement('div');
    botMsg.className = 'msg bot';
    botMsg.textContent = "Thanks for reaching out! For inquiries, email vnresolutions@gmail.com.";
    body.appendChild(botMsg);

    input.value = '';
    body.scrollTop = body.scrollHeight;
  }
});